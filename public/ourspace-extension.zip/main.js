// Page adapter (runs inside the streaming page itself, after services.js): reads the player and plays, pauses and
// seeks it. Netflix crashes if its <video> is seeked directly, so it uses Netflix's own player API; every other
// service uses the page's <video> (found inside shadow DOM too, e.g. Apple TV+).
(() => {
  if (window.__ourspaceMain) return;
  const S = self.OURSPACE_SERVICES; const service = S && self.ourspaceServiceFor(location.hostname);
  if (!service) return;
  const svc = S[service];
  if (svc.frames && window === window.top) return; if (!svc.frames && window !== window.top) return; // the player frame reports, not the page around it
  window.__ourspaceMain = true;
  const post = msg => window.postMessage({ src: 'ourspace-page', ...msg }, '*');
  let quietUntil = 0; // our own commands don't count as the person's actions

  function nfPlayer() {
    try {
      const vp = window.netflix.appContext.state.playerApp.getAPI().videoPlayer;
      const ids = vp.getAllPlayerSessionIds();
      return ids.length ? vp.getVideoPlayerBySessionId(ids[ids.length - 1]) : null;
    } catch { return null; }
  }
  // The biggest playing-capable <video> on the page, looking inside open shadow roots when the page has none.
  let cached = null;
  function allVideos() {
    const found = [...document.querySelectorAll('video')];
    if (found.length) return found;
    const out = []; const walk = root => { root.querySelectorAll('*').forEach(el => { if (el.shadowRoot) { out.push(...el.shadowRoot.querySelectorAll('video')); walk(el.shadowRoot); } }); };
    try { walk(document); } catch { /* fine */ }
    return out;
  }
  function video() {
    if (cached && cached.isConnected && cached.duration > 0) return cached;
    const list = allVideos().filter(v => v.readyState > 0 && v.duration > 0 && v.offsetWidth > 0);
    list.sort((a, b) => b.offsetWidth * b.offsetHeight - a.offsetWidth * a.offsetHeight);
    return (cached = list[0] || null);
  }
  function titleText() {
    for (const sel of svc.title || []) { const el = document.querySelector(sel); const t = el?.textContent?.trim(); if (t) return t.slice(0, 120); }
    const name = svc.name.replace(/[+]/g, '\\+');
    return (document.title || '').replace(new RegExp(`\\s*[|–-]\\s*(Watch\\s+)?(on\\s+)?${name}.*$`, 'i'), '').replace(new RegExp(`^${name}\\s*[|–-]\\s*`, 'i'), '').trim().slice(0, 120);
  }
  function state() {
    const v = video(); const p = svc.seek === 'netflix' ? nfPlayer() : null;
    const t = p ? p.getCurrentTime() / 1000 : v ? v.currentTime : 0;
    const paused = p ? p.isPaused() : v ? v.paused : true;
    return { id: svc.id(location), url: window === window.top ? location.href : '', title: titleText(), t, paused, ready: !!v && v.readyState >= 3, duration: v ? v.duration : 0 };
  }
  const seekTo = (p, v, t) => { if (p) p.seek(Math.round(t * 1000)); else if (v) v.currentTime = t; };
  function run(action, t) {
    quietUntil = Date.now() + 900;
    const p = svc.seek === 'netflix' ? nfPlayer() : null; const v = video();
    try {
      if (action === 'seek' && typeof t === 'number') seekTo(p, v, t);
      if (action === 'play') { if (typeof t === 'number' && Math.abs(state().t - t) > 0.6) seekTo(p, v, t); if (p) p.play(); else void v?.play(); }
      if (action === 'pause') { if (p) p.pause(); else v?.pause(); if (typeof t === 'number') seekTo(p, v, t); }
    } catch { /* player not ready yet */ }
    setTimeout(() => post({ type: 'state', state: state() }), 300);
  }
  window.addEventListener('message', e => { if (e.source === window && e.data?.src === 'ourspace-cs' && e.data.type === 'cmd') run(e.data.action, e.data.t); });

  // The person's own play / pause / seek on the site's controls.
  const watched = new WeakSet();
  const hook = () => {
    const v = video(); if (!v || watched.has(v)) return; watched.add(v);
    const user = action => { if (Date.now() < quietUntil) return; post({ type: 'user', action, t: state().t }); };
    v.addEventListener('play', () => user('play'));
    v.addEventListener('pause', () => { if (!v.ended && !v.seeking) user('pause'); });
    v.addEventListener('seeked', () => user('seek'));
  };
  setInterval(() => { hook(); post({ type: 'state', state: state() }); }, 1000);
  // These sites change pages without reloading: report the new title quickly.
  let href = location.href;
  setInterval(() => { if (location.href !== href) { href = location.href; cached = null; post({ type: 'state', state: state() }); } }, 400);
})();
