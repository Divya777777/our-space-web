// Page adapter (runs inside the Netflix / Prime page itself): reads the player and plays, pauses and seeks it.
// Netflix crashes if its <video> is seeked directly, so it uses Netflix's own player API; Prime uses the <video>.
(() => {
  if (window.__ourspaceMain) return; window.__ourspaceMain = true;
  const service = /netflix\.com$/.test(location.hostname) ? 'netflix' : 'prime';
  const post = msg => window.postMessage({ src: 'ourspace-page', ...msg }, '*');
  let quietUntil = 0; // our own commands don't count as the person's actions

  function nfPlayer() {
    try {
      const vp = window.netflix.appContext.state.playerApp.getAPI().videoPlayer;
      const ids = vp.getAllPlayerSessionIds();
      return ids.length ? vp.getVideoPlayerBySessionId(ids[ids.length - 1]) : null;
    } catch { return null; }
  }
  function video() {
    const list = [...document.querySelectorAll('video')].filter(v => v.readyState > 0 && v.duration > 0 && v.offsetWidth > 0);
    list.sort((a, b) => b.offsetWidth * b.offsetHeight - a.offsetWidth * a.offsetHeight);
    return list[0] || null;
  }
  function titleId() {
    if (service === 'netflix') { const m = location.pathname.match(/\/watch\/(\d+)/); return m ? 'nf:' + m[1] : ''; }
    const q = new URLSearchParams(location.search);
    const gti = q.get('gti'); if (gti) return 'pv:' + gti;
    const m = location.pathname.match(/\/(?:detail|dp)\/([A-Za-z0-9.\-]+)/); return m ? 'pv:' + m[1] : '';
  }
  function titleText() {
    const sel = service === 'netflix' ? '[data-uia="video-title"] h4, [data-uia="video-title"]' : '.atvwebplayersdk-title-text, [data-automation-id="title"]';
    const el = document.querySelector(sel);
    return (el?.textContent || document.title || '').replace(/\s*[|–-]\s*(Netflix|Prime Video).*$/i, '').trim().slice(0, 120);
  }
  function state() {
    const v = video(); const p = service === 'netflix' ? nfPlayer() : null;
    const t = p ? p.getCurrentTime() / 1000 : v ? v.currentTime : 0;
    const paused = p ? p.isPaused() : v ? v.paused : true;
    return { id: titleId(), url: location.href, title: titleText(), t, paused, ready: !!v && v.readyState >= 3, duration: v ? v.duration : 0 };
  }
  function run(action, t) {
    quietUntil = Date.now() + 900;
    const p = service === 'netflix' ? nfPlayer() : null; const v = video();
    try {
      if (action === 'seek' && typeof t === 'number') { if (p) p.seek(Math.round(t * 1000)); else if (v) v.currentTime = t; }
      if (action === 'play') { if (typeof t === 'number' && Math.abs(state().t - t) > 0.6) { if (p) p.seek(Math.round(t * 1000)); else if (v) v.currentTime = t; } if (p) p.play(); else void v?.play(); }
      if (action === 'pause') { if (p) p.pause(); else v?.pause(); if (typeof t === 'number') { if (p) p.seek(Math.round(t * 1000)); else if (v) v.currentTime = t; } }
    } catch { /* player not ready yet */ }
    setTimeout(() => post({ type: 'state', state: state() }), 300);
  }
  window.addEventListener('message', e => { if (e.source === window && e.data?.src === 'ourspace-cs' && e.data.type === 'cmd') run(e.data.action, e.data.t); });

  // The person's own play / pause / seek on the site's controls.
  const watched = new WeakSet();
  const hook = () => {
    const v = video(); if (!v || watched.has(v)) return; watched.add(v);
    const user = action => { if (Date.now() < quietUntil) return; post({ type: 'user', action, t: state().t }); };
    v.addEventListener('play', () => user('play'));
    v.addEventListener('pause', () => { if (!v.ended && !v.seeking) user('pause'); });
    v.addEventListener('seeked', () => user('seek'));
  };
  let last = '';
  setInterval(() => { hook(); const s = state(); const key = JSON.stringify([s.id, s.ready, s.paused, Math.round(s.t)]); post({ type: 'state', state: s }); last = key; }, 1000);
  // Netflix and Prime change pages without reloading: report the new title quickly.
  let href = location.href;
  setInterval(() => { if (location.href !== href) { href = location.href; post({ type: 'state', state: state() }); } }, 400);
})();
