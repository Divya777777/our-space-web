// The streaming services Our Space can watch together, shared by every part of the extension.
// Each entry: name, where "open" goes, which hosts it runs on, which URLs count as still being on the service,
// how to tell which title is open (so both people are on the same one) and where the title's name is on the page.
// frames: the player lives inside an iframe (that frame reports, not the page around it).
// seek: 'netflix' uses Netflix's own player API (seeking its <video> directly crashes it); everything else sets
// the <video>'s currentTime.
(() => {
  const path = l => l.pathname.replace(/\/+$/, '');
  const S = {
    netflix: {
      name: 'Netflix', home: 'https://www.netflix.com/browse', hosts: [/(^|\.)netflix\.com$/],
      on: u => /^https:\/\/www\.netflix\.com\//.test(u), seek: 'netflix',
      id: l => { const m = l.pathname.match(/\/watch\/(\d+)/); return m ? 'nf:' + m[1] : ''; },
      title: ['[data-uia="video-title"] h4', '[data-uia="video-title"]'],
    },
    prime: {
      name: 'Prime Video', home: 'https://www.primevideo.com/', hosts: [/(^|\.)primevideo\.com$/, /(^|\.)amazon\.(com|in|co\.uk|de|ca|com\.au|co\.jp|fr|it|es)$/],
      on: u => /^https:\/\/www\.(primevideo\.com|amazon\.[a-z.]+\/(gp\/video|.*\/dp\/))/.test(u),
      id: l => { const g = new URLSearchParams(l.search).get('gti'); if (g) return 'pv:' + g; const m = l.pathname.match(/\/(?:detail|dp)\/([A-Za-z0-9.\-]+)/); return m ? 'pv:' + m[1] : ''; },
      title: ['.atvwebplayersdk-title-text', '[data-automation-id="title"]'],
    },
    appletv: {
      name: 'Apple TV+', home: 'https://tv.apple.com/', hosts: [/^tv\.apple\.com$/],
      on: u => /^https:\/\/tv\.apple\.com\//.test(u),
      id: l => { const m = l.pathname.match(/\/(umc\.cmc\.[a-z0-9]+)/); const e = new URLSearchParams(l.search).get('episodeId'); return m ? 'atv:' + m[1] + (e ? ':' + e : '') : ''; },
      title: ['.video-player__title', '.product-header__title', 'h1'],
    },
    hotstar: {
      name: 'JioHotstar', home: 'https://www.hotstar.com/', hosts: [/(^|\.)hotstar\.com$/],
      on: u => /^https:\/\/www\.hotstar\.com\//.test(u),
      id: l => { const m = l.pathname.match(/\/(\d{6,})(?:\/watch)?$/) || l.pathname.match(/\/(\d{6,})/); return m ? 'hs:' + m[1] : ''; },
      title: ['[data-testid="player-title"]', '.player-title', 'h1'],
    },
    disney: {
      name: 'Disney+', home: 'https://www.disneyplus.com/', hosts: [/(^|\.)disneyplus\.com$/],
      on: u => /^https:\/\/www\.disneyplus\.com\//.test(u),
      id: l => { const m = l.pathname.match(/\/(?:video|play)\/([a-f0-9-]{8,})/i); return m ? 'dp:' + m[1] : ''; },
      title: ['.title-field', '[data-testid="title"]', 'h1'],
    },
    max: {
      name: 'HBO Max', home: 'https://play.hbomax.com/', hosts: [/(^|\.)hbomax\.com$/, /(^|\.)max\.com$/],
      on: u => /^https:\/\/play\.(hbo)?max\.com\//.test(u),
      id: l => { const m = l.pathname.match(/\/video\/watch\/([^/]+)(?:\/([^/]+))?/); return m ? 'mx:' + (m[2] || m[1]) : ''; },
      title: ['[data-testid="player-ux-asset-title"]', '[class*="TitleText"]', 'h1'],
    },
    crunchyroll: {
      name: 'Crunchyroll', home: 'https://www.crunchyroll.com/', hosts: [/(^|\.)crunchyroll\.com$/], frames: true,
      on: u => /^https:\/\/www\.crunchyroll\.com\//.test(u),
      // The player is an iframe; its own address doesn't say which episode, so the episode comes from the page.
      id: () => { try { const m = (document.referrer || '').match(/\/watch\/([A-Z0-9]+)/); return m ? 'cr:' + m[1] : ''; } catch { return ''; } },
      title: ['.show-title-link h4', 'h1.title'],
    },
    sonyliv: {
      name: 'Sony LIV', home: 'https://www.sonyliv.com/', hosts: [/(^|\.)sonyliv\.com$/],
      on: u => /^https:\/\/www\.sonyliv\.com\//.test(u),
      id: l => { const m = l.pathname.match(/-(\d{6,})(?:$|\/)/) || l.pathname.match(/\/(\d{6,})/); return m ? 'sl:' + m[1] : ''; },
      title: ['.playerTitle', 'h1'],
    },
    zee5: {
      name: 'ZEE5', home: 'https://www.zee5.com/', hosts: [/(^|\.)zee5\.com$/],
      on: u => /^https:\/\/www\.zee5\.com\//.test(u),
      id: l => { const m = l.pathname.match(/\/(0-[0-9]-[^/]+)$/) || l.pathname.match(/\/(0-[0-9]-[^/]+)/); return m ? 'z5:' + m[1] : ''; },
      title: ['.playerTitle', 'h1'],
    },
  };
  // Fallback when a service's address doesn't name the title clearly: the page's path.
  for (const k of Object.keys(S)) { const own = S[k].id; S[k].id = l => own(l) || (k + ':' + path(l)); }
  self.OURSPACE_SERVICES = S;
  self.ourspaceServiceFor = host => Object.keys(S).find(k => S[k].hosts.some(r => r.test(host))) || null;
})();
