// Runs on the Our Space website: tells the page the extension is here, and carries messages between the page and
// the extension. Only Our Space pages get this script.
(() => {
  if (window.__ourspaceSite) return; window.__ourspaceSite = true;
  const VERSION = chrome.runtime.getManifest().version;
  let port = null;
  const connect = () => {
    try { port = chrome.runtime.connect({ name: 'app' }); } catch { port = null; return; }
    port.onMessage.addListener(msg => window.postMessage({ src: 'ourspace-ext', ...msg }, location.origin));
    port.onDisconnect.addListener(() => { port = null; setTimeout(connect, 500); });
  };
  connect();
  const hello = () => {
    document.documentElement.dataset.ourspaceExt = VERSION;
    window.postMessage({ src: 'ourspace-ext', type: 'hello', version: VERSION }, location.origin);
  };
  if (document.documentElement) hello(); else document.addEventListener('DOMContentLoaded', hello);
  window.addEventListener('message', e => {
    if (e.source !== window || e.origin !== location.origin || !e.data || e.data.src !== 'ourspace-app') return;
    if (e.data.type === 'ping') { hello(); return; }
    if (!port) connect();
    const { src, ...msg } = e.data;
    try { port?.postMessage(msg); } catch { /* reconnecting */ }
  });
})();
