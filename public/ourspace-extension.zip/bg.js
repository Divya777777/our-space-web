// The extension's hub: Our Space tabs ("app") ask it to open a streaming service and to play, pause or seek; the
// streaming tab ("player") reports what is playing. Nothing leaves this computer from here: the Our Space page
// shares it with the other person over the call, which is end-to-end between you.
// The services table (services.js) is loaded first: by importScripts in Chrome's service worker, or listed before
// this file in Firefox's background scripts.
if (!self.OURSPACE_SERVICES && typeof importScripts === 'function') importScripts('services.js');
const SERVICES = Object.fromEntries(Object.entries(self.OURSPACE_SERVICES).map(([k, v]) => [k, { home: v.home, match: v.on }]));
const apps = new Set(); // ports from Our Space tabs
const players = new Map(); // tabId -> port
let party = null; // { service, tabId }

const toApps = msg => apps.forEach(p => { try { p.postMessage(msg); } catch { /* gone */ } });
const toPlayer = msg => { const port = party?.tabId != null ? players.get(party.tabId) : null; try { port?.postMessage(msg); } catch { /* gone */ } return !!port; };

async function open(service, url, focus) {
  const svc = SERVICES[service]; if (!svc) return;
  const target = url && svc.match(url) ? url : svc.home;
  let tabId = party?.service === service ? party.tabId : null;
  if (tabId != null) { try { await chrome.tabs.get(tabId); } catch { tabId = null; } }
  if (tabId == null) {
    const tab = await chrome.tabs.create({ url: target, active: focus !== false });
    tabId = tab.id;
  } else {
    const tab = await chrome.tabs.get(tabId);
    if (url && tab.url !== target) await chrome.tabs.update(tabId, { url: target });
    if (focus !== false) { await chrome.tabs.update(tabId, { active: true }); await chrome.windows.update(tab.windowId, { focused: true }); }
  }
  party = { service, tabId };
  toApps({ type: 'opened', service, tabId });
}

chrome.runtime.onConnect.addListener(port => {
  if (port.name === 'app') {
    apps.add(port);
    port.onDisconnect.addListener(() => apps.delete(port));
    port.onMessage.addListener(msg => {
      if (msg.type === 'open') void open(msg.service, msg.url, msg.focus);
      else if (msg.type === 'focus' && party) void chrome.tabs.get(party.tabId).then(t => { chrome.tabs.update(t.id, { active: true }); chrome.windows.update(t.windowId, { focused: true }); }).catch(() => {});
      else if (msg.type === 'badge') toPlayer(msg);
      else if (msg.type === 'cmd' || msg.type === 'overlay') { if (!toPlayer(msg) && msg.type === 'cmd') toApps({ type: 'player-missing' }); }
      else if (msg.type === 'end') { toPlayer({ type: 'overlay', text: '' }); party = null; }
      else if (msg.type === 'status') toApps({ type: 'status', party, players: players.size });
    });
    return;
  }
  if (port.name === 'player') {
    const tabId = port.sender?.tab?.id; if (tabId == null) return;
    players.set(tabId, port);
    // The page adapter (main.js) is declared to run in the page itself; add it here too in case the page was open
    // before the extension (harmless when it's already there).
    const frameIds = port.sender?.frameId != null ? [port.sender.frameId] : undefined;
    void chrome.scripting.executeScript({ target: { tabId, ...(frameIds ? { frameIds } : {}) }, world: 'MAIN', files: ['services.js', 'main.js'] }).catch(() => {});
    // A page change inside Netflix / Prime reconnects in a moment; only a closed tab or leaving the site ends it.
    port.onDisconnect.addListener(() => { if (players.get(tabId) === port) players.delete(tabId); });
    port.onMessage.addListener(msg => {
      // A Netflix / Prime tab the person opened themselves joins the party when it's the same service.
      if (msg.type === 'state' && (!party || (party.service === msg.state.service && party.tabId !== tabId && !players.has(party.tabId)))) party = { service: msg.state.service, tabId };
      if (party?.tabId !== tabId) return;
      // The Our Space badge on the video: "Back to the call" brings the Our Space tab forward.
      if (msg.type === 'action' && msg.action === 'app') { for (const p of apps) { const t = p.sender?.tab; if (t) { chrome.tabs.update(t.id, { active: true }); chrome.windows.update(t.windowId, { focused: true }); break; } } return; }
      toApps({ ...msg, tabId });
    });
  }
});

// The Our Space site can ask "are you there?" directly (works right after installing, no page reload needed).
chrome.runtime.onMessageExternal.addListener((msg, _sender, reply) => {
  if (msg?.type === 'ping') reply({ version: chrome.runtime.getManifest().version });
});

chrome.tabs.onRemoved.addListener(tabId => { if (party?.tabId === tabId) toApps({ type: 'player-gone', tabId }); });
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (party?.tabId !== tabId || !info.url) return;
  if (!SERVICES[party.service].match(info.url)) toApps({ type: 'player-gone', tabId });
});

// Installed or updated while pages are already open: add the scripts to them now (Chrome only does it on reload).
chrome.runtime.onInstalled.addListener(async () => {
  const manifest = chrome.runtime.getManifest();
  for (const cs of manifest.content_scripts) {
    const tabs = await chrome.tabs.query({ url: cs.matches }).catch(() => []);
    for (const t of tabs) void chrome.scripting.executeScript({ target: { tabId: t.id, allFrames: !!cs.all_frames }, files: cs.js, ...(cs.world === 'MAIN' ? { world: 'MAIN' } : {}) }).catch(() => {});
  }
});
