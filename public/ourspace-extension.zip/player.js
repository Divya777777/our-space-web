// Runs on the supported streaming sites (services.js). Reports what is playing to the Our Space tab and follows play / pause / seek
// from the other person, through the page adapter (main.js). Also shows a small glass notice on top of the video.
(() => {
  if (window.__ourspacePlayer) return;
  const S = self.OURSPACE_SERVICES; const service = S && self.ourspaceServiceFor(location.hostname);
  if (!service) return;
  if (S[service].frames && window === window.top) return; if (!S[service].frames && window !== window.top) return; // ads and other frames on the page // the player frame handles it
  window.__ourspacePlayer = true;
  let port = null;
  const connect = () => {
    try { port = chrome.runtime.connect({ name: 'player' }); } catch { port = null; return; }
    port.onMessage.addListener(onCommand);
    port.onDisconnect.addListener(() => { port = null; setTimeout(connect, 800); });
  };
  const send = msg => { try { port?.postMessage(msg); } catch { /* reconnecting */ } };
  connect();

  // Page adapter <-> this script
  const toPage = msg => window.postMessage({ src: 'ourspace-cs', ...msg }, '*');
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.src !== 'ourspace-page') return;
    if (e.data.type === 'state') send({ type: 'state', state: { ...e.data.state, service } });
    else if (e.data.type === 'user') send({ type: 'user', action: e.data.action, t: e.data.t, service });
  });
  function onCommand(msg) {
    if (msg.type === 'cmd') toPage({ type: 'cmd', action: msg.action, t: msg.t });
    else if (msg.type === 'overlay') overlay(msg.text, msg.tone, msg.ms);
    else if (msg.type === 'badge') badge(msg.text, msg.tone, msg.names || []);
  }

  // Our Space badge on the video while watching together: status, Sync, Back to app. Drag it anywhere; it remembers where.
  let badgeHost = null, badgeEl = null, idle = 0;
  function badge(text, tone, names) {
    if (!text) { badgeHost?.remove(); badgeHost = null; return; }
    if (!badgeHost) {
      badgeHost = document.createElement('div');
      badgeHost.style.cssText = 'position:fixed;left:24px;bottom:96px;z-index:2147483646';
      const root = badgeHost.attachShadow({ mode: 'open' });
      root.innerHTML = `<style>
        .b{font:500 13px/1.25 Outfit,system-ui,-apple-system,Segoe UI,sans-serif;color:#F4F1EA;display:flex;align-items:center;gap:10px;padding:8px 8px 8px 10px;border-radius:999px;
          background:linear-gradient(135deg,rgba(32,28,58,.72),rgba(12,16,28,.62));backdrop-filter:blur(20px) saturate(1.5);-webkit-backdrop-filter:blur(20px) saturate(1.5);
          border:1px solid rgba(200,182,255,.28);box-shadow:0 16px 40px -14px rgba(0,0,0,.8),inset 0 1px 0 rgba(255,255,255,.14);transition:opacity .4s,transform .4s cubic-bezier(.2,1.3,.4,1);animation:in .6s cubic-bezier(.2,1.3,.4,1)}
        .b{cursor:grab;user-select:none;-webkit-user-select:none;touch-action:none}.b.dragging{cursor:grabbing;transition:none;opacity:1}.b.idle{opacity:.35}.b:hover{opacity:1;transform:translateY(-2px)}
        @keyframes in{from{opacity:0;transform:translateY(12px) scale(.96)}}
        .logo{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;background:radial-gradient(circle at 35% 30%,#E2D8FF,#C8B6FF 45%,#7C62D6);color:#141125;font-size:14px;flex:none;box-shadow:0 0 16px rgba(200,182,255,.55)}
        .dot{width:8px;height:8px;border-radius:50%;background:#E6C994;flex:none;animation:p 1.6s infinite}.ok .dot{background:#B6DDCF}
        @keyframes p{0%{box-shadow:0 0 0 0 rgba(182,221,207,.5)}70%{box-shadow:0 0 0 7px rgba(182,221,207,0)}}
        .t{display:flex;flex-direction:column}.s{font-size:11px;color:#ADB5CA}
        button{font:600 12px Outfit,system-ui,sans-serif;color:#F4F1EA;background:rgba(255,255,255,.1);border:0;border-radius:999px;padding:7px 11px;cursor:pointer;transition:background .2s}
        button:hover{background:#C8B6FF;color:#141125}
      </style><div class="b"><span class="logo">✦</span><span class="dot"></span><span class="t"><b class="m"></b><span class="s">Our Space</span></span><button data-a="resync" title="Put everyone at your moment">Sync</button><button data-a="app" title="Back to Our Space (your call and chat)">Back to app</button></div>`;
      badgeEl = root.querySelector('.b');
      let moved = false;
      root.querySelectorAll('button').forEach(b => b.addEventListener('click', e => { if (moved) { e.preventDefault(); e.stopPropagation(); return; } send({ type: 'action', action: b.dataset.a }); }));
      // Drag from anywhere on the badge (a short move still counts as a click on its buttons).
      const KEY = 'ourspace.badgePos';
      const place = (x, y) => {
        const w = badgeEl.offsetWidth || 260, h = badgeEl.offsetHeight || 44;
        x = Math.max(8, Math.min(innerWidth - w - 8, x)); y = Math.max(8, Math.min(innerHeight - h - 8, y));
        badgeHost.style.left = x + 'px'; badgeHost.style.top = y + 'px'; badgeHost.style.bottom = 'auto';
        return { x, y };
      };
      try { const saved = JSON.parse(localStorage.getItem(KEY) || 'null'); if (saved) requestAnimationFrame(() => place(saved.x * innerWidth, saved.y * innerHeight)); } catch { /* first time */ }
      badgeEl.addEventListener('pointerdown', e => {
        if (e.button !== 0) return;
        const r = badgeHost.getBoundingClientRect(); const dx = e.clientX - r.left, dy = e.clientY - r.top, sx = e.clientX, sy = e.clientY;
        moved = false; let last = null;
        const move = ev => {
          if (!moved && Math.hypot(ev.clientX - sx, ev.clientY - sy) < 6) return;
          if (!moved) { moved = true; badgeEl.classList.add('dragging'); try { badgeEl.setPointerCapture(e.pointerId); } catch { /* fine */ } }
          ev.preventDefault(); last = place(ev.clientX - dx, ev.clientY - dy);
        };
        const up = () => {
          removeEventListener('pointermove', move, true); removeEventListener('pointerup', up, true); removeEventListener('pointercancel', up, true);
          badgeEl.classList.remove('dragging');
          if (last) try { localStorage.setItem(KEY, JSON.stringify({ x: last.x / innerWidth, y: last.y / innerHeight })); } catch { /* private window */ }
          setTimeout(() => { moved = false; }, 0);
        };
        addEventListener('pointermove', move, true); addEventListener('pointerup', up, true); addEventListener('pointercancel', up, true);
      });
      addEventListener('resize', () => { if (badgeHost && badgeHost.style.top) { const r = badgeHost.getBoundingClientRect(); place(r.left, r.top); } });
      (document.fullscreenElement || document.body || document.documentElement).appendChild(badgeHost);
      // Fades back when the mouse rests, like the site's own controls.
      document.addEventListener('mousemove', () => { badgeEl?.classList.remove('idle'); clearTimeout(idle); idle = setTimeout(() => badgeEl?.classList.add('idle'), 3000); }, true);
    }
    badgeEl.classList.toggle('ok', tone === 'ok');
    badgeEl.querySelector('.m').textContent = text;
  }

  // Glass notice (shadow DOM so the site's styles can't touch it).
  let host = null, box = null, hideTimer = 0;
  function overlay(text, tone = 'info', ms = 0) {
    if (!host) {
      host = document.createElement('div');
      host.style.cssText = 'position:fixed;left:50%;top:22px;transform:translateX(-50%);z-index:2147483647;pointer-events:none';
      const root = host.attachShadow({ mode: 'open' });
      root.innerHTML = `<style>
        .n{font:600 14px/1.3 Outfit,system-ui,-apple-system,Segoe UI,sans-serif;color:#F4F1EA;display:flex;align-items:center;gap:10px;padding:11px 18px 11px 12px;border-radius:999px;
          background:rgba(16,18,34,.62);backdrop-filter:blur(18px) saturate(1.4);-webkit-backdrop-filter:blur(18px) saturate(1.4);border:1px solid rgba(255,255,255,.16);
          box-shadow:0 18px 50px -12px rgba(0,0,0,.7),inset 0 1px 0 rgba(255,255,255,.12);opacity:0;transform:translateY(-12px) scale(.96);transition:opacity .35s,transform .45s cubic-bezier(.2,1.4,.4,1)}
        .n.on{opacity:1;transform:none}
        .d{width:22px;height:22px;border-radius:50%;display:grid;place-items:center;background:#C8B6FF;color:#141125;font-size:13px;flex:none}
        .ok .d{background:#B6DDCF}.warn .d{background:#E6C994}
        .ring{animation:p 1.6s ease-in-out infinite}@keyframes p{50%{box-shadow:0 0 0 7px rgba(200,182,255,.18)}}
      </style><div class="n"><span class="d">✦</span><span class="t"></span></div>`;
      box = root.querySelector('.n');
      (document.body || document.documentElement).appendChild(host);
    }
    clearTimeout(hideTimer);
    if (!text) { box.classList.remove('on'); return; }
    box.className = 'n ' + (tone === 'ok' ? 'ok' : tone === 'warn' ? 'warn' : '');
    box.querySelector('.d').textContent = tone === 'ok' ? '✓' : tone === 'warn' ? '!' : '✦';
    box.querySelector('.d').classList.toggle('ring', tone === 'wait');
    box.querySelector('.t').textContent = text;
    requestAnimationFrame(() => box.classList.add('on'));
    if (ms) hideTimer = setTimeout(() => box.classList.remove('on'), ms);
  }
  // Fullscreen moves the video into its own layer: move the notice with it.
  document.addEventListener('fullscreenchange', () => { const into = document.fullscreenElement || document.body; if (host) into.appendChild(host); if (badgeHost) into.appendChild(badgeHost); });
})();
