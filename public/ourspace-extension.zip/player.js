// Runs on Netflix and Prime Video. Reports what is playing to the Our Space tab and follows play / pause / seek
// from the other person, through the page adapter (main.js). Also shows a small glass notice on top of the video.
(() => {
  if (window.__ourspacePlayer) return; window.__ourspacePlayer = true;
  const service = /netflix\.com$/.test(location.hostname) ? 'netflix' : 'prime';
  let port = null;
  const connect = () => {
    try { port = chrome.runtime.connect({ name: 'player' }); } catch { port = null; return; }
    port.onMessage.addListener(onCommand);
    port.onDisconnect.addListener(() => { port = null; setTimeout(connect, 800); });
  };
  const send = msg => { try { port?.postMessage(msg); } catch { /* reconnecting */ } };
  connect();

  // Page adapter <-> this script
  const toPage = msg => window.postMessage({ src: 'ourspace-cs', ...msg }, '*');
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.src !== 'ourspace-page') return;
    if (e.data.type === 'state') send({ type: 'state', state: { ...e.data.state, service } });
    else if (e.data.type === 'user') send({ type: 'user', action: e.data.action, t: e.data.t, service });
  });
  function onCommand(msg) {
    if (msg.type === 'cmd') toPage({ type: 'cmd', action: msg.action, t: msg.t });
    else if (msg.type === 'overlay') overlay(msg.text, msg.tone, msg.ms);
  }

  // Glass notice (shadow DOM so the site's styles can't touch it).
  let host = null, box = null, hideTimer = 0;
  function overlay(text, tone = 'info', ms = 0) {
    if (!host) {
      host = document.createElement('div');
      host.style.cssText = 'position:fixed;left:50%;top:22px;transform:translateX(-50%);z-index:2147483647;pointer-events:none';
      const root = host.attachShadow({ mode: 'open' });
      root.innerHTML = `<style>
        .n{font:600 14px/1.3 Outfit,system-ui,-apple-system,Segoe UI,sans-serif;color:#F4F1EA;display:flex;align-items:center;gap:10px;padding:11px 18px 11px 12px;border-radius:999px;
          background:rgba(16,18,34,.62);backdrop-filter:blur(18px) saturate(1.4);-webkit-backdrop-filter:blur(18px) saturate(1.4);border:1px solid rgba(255,255,255,.16);
          box-shadow:0 18px 50px -12px rgba(0,0,0,.7),inset 0 1px 0 rgba(255,255,255,.12);opacity:0;transform:translateY(-12px) scale(.96);transition:opacity .35s,transform .45s cubic-bezier(.2,1.4,.4,1)}
        .n.on{opacity:1;transform:none}
        .d{width:22px;height:22px;border-radius:50%;display:grid;place-items:center;background:#C8B6FF;color:#141125;font-size:13px;flex:none}
        .ok .d{background:#B6DDCF}.warn .d{background:#E6C994}
        .ring{animation:p 1.6s ease-in-out infinite}@keyframes p{50%{box-shadow:0 0 0 7px rgba(200,182,255,.18)}}
      </style><div class="n"><span class="d">✦</span><span class="t"></span></div>`;
      box = root.querySelector('.n');
      (document.body || document.documentElement).appendChild(host);
    }
    clearTimeout(hideTimer);
    if (!text) { box.classList.remove('on'); return; }
    box.className = 'n ' + (tone === 'ok' ? 'ok' : tone === 'warn' ? 'warn' : '');
    box.querySelector('.d').textContent = tone === 'ok' ? '✓' : tone === 'warn' ? '!' : '✦';
    box.querySelector('.d').classList.toggle('ring', tone === 'wait');
    box.querySelector('.t').textContent = text;
    requestAnimationFrame(() => box.classList.add('on'));
    if (ms) hideTimer = setTimeout(() => box.classList.remove('on'), ms);
  }
  // Fullscreen moves the video into its own layer: move the notice with it.
  document.addEventListener('fullscreenchange', () => { if (host) (document.fullscreenElement || document.body).appendChild(host); });
})();
